document.addEventListener("change", (event) => {
  const select = event.target.closest("[data-variant-select]");
  if (!select) return;

  const form = select.closest("[data-product-form]");
  const hiddenInput = form?.querySelector('input[name="id"]');
  const priceTarget = form?.closest("[data-product-shell]")?.querySelector("[data-current-price]");
  const selectedOption = select.options[select.selectedIndex];

  if (hiddenInput) hiddenInput.value = select.value;
  if (priceTarget && selectedOption?.dataset.price) {
    priceTarget.textContent = selectedOption.dataset.price;
  }
});
