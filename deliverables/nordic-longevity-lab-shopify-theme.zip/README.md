# Nordic Longevity Lab Shopify Theme

Local Shopify theme scaffold for the ecommerce delivery plan.

## Status

This is a local Online Store 2.0-style scaffold. It has not been uploaded to Shopify or tested with Shopify Theme Check yet.

## Structure

- `layout/theme.liquid`: global layout, header, footer
- `templates/index.json`: homepage section order
- `templates/product.json`: product page section order
- `sections/hero-lab.liquid`: homepage hero
- `sections/product-showcase.liquid`: 2-product showcase
- `sections/main-product-lab.liquid`: product page buy box
- `sections/quality-passport.liquid`: metafield-driven documentation module
- `sections/evidence-tabs.liquid`: evidence/claim-safety modules
- `sections/delivery-payment.liquid`: Vipps/card/Posten explanation section
- `sections/lab-notes.liquid`: article grid
- `snippets/product-card-lab.liquid`: reusable product card with variant selector
- `assets/theme.css`: storefront styling
- `assets/theme.js`: variant price helper

## Required Product Metafields

Use namespace `lab`:

- `batch_id`
- `origin`
- `lab_name`
- `test_method`
- `certificate_url`
- `serving_condition`
- `serving_size`
- `daily_dose`
- `servings`
- `warnings`

See `../docs/SHOPIFY_METAFIELDS.md` for the full setup plan.

## Next Steps

1. Create Shopify development store or theme target.
2. Add products and variants.
3. Add the `lab` metafield definitions.
4. Upload this theme or port sections into the chosen base theme.
5. Configure Shopify Payments, Vipps/MobilePay and Posten Bring Checkout.
6. Run Shopify Theme Check.
7. Test checkout and fulfillment.
